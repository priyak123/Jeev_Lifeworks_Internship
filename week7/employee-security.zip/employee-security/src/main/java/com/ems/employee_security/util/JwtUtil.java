package com.ems.employee_security.util;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.*;

import java.util.Base64;

@Component
public class JwtUtil {

	private static final String SECRET_KEY = "my-super-secret-key-123456789"; // keep it private
	private static final long EXPIRATION_TIME_MS = 1000 * 60 * 60; // 1 hour

	// 🔐 Generate token
	public String generateToken(String username, String role) {
		long now = System.currentTimeMillis();
		long exp = now + EXPIRATION_TIME_MS;

		String headerJson = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
		String payloadJson = String.format("{\"sub\":\"%s\",\"role\":\"%s\",\"exp\":%d}", username, role, exp);

		String encodedHeader = Base64.getUrlEncoder().withoutPadding().encodeToString(headerJson.getBytes());
		String encodedPayload = Base64.getUrlEncoder().withoutPadding().encodeToString(payloadJson.getBytes());

		String signature = hmacSha256(encodedHeader + "." + encodedPayload, SECRET_KEY);
		return encodedHeader + "." + encodedPayload + "." + signature;
	}

	// 🧪 Validate token
	public boolean validateToken(String token) {
		try {
			String[] parts = token.split("\\.");
			if (parts.length != 3)
				return false;

			String header = parts[0];
			String payload = parts[1];
			String signature = parts[2];

			String expectedSig = hmacSha256(header + "." + payload, SECRET_KEY);
			if (!expectedSig.equals(signature))
				return false;

			String json = new String(Base64.getUrlDecoder().decode(payload));
			long exp = (long) ((Map<String, Object>) new ObjectMapper().readValue(json, Map.class)).get("exp");

			return System.currentTimeMillis() < exp;
		} catch (Exception e) {
			return false;
		}
	}

	// 📥 Extract username from token
	public String getUsername(String token) {
		String payload = token.split("\\.")[1];
		String json = new String(Base64.getUrlDecoder().decode(payload));
		return (String) ((Map<String, Object>) parseJson(json)).get("sub");
	}

	// 📥 Extract role from token
	public String getRole(String token) {
		String payload = token.split("\\.")[1];
		String json = new String(Base64.getUrlDecoder().decode(payload));
		return (String) ((Map<String, Object>) parseJson(json)).get("role");
	}

	// 🔐 Sign HMAC SHA-256
	private String hmacSha256(String data, String key) {
		try {
			Mac mac = Mac.getInstance("HmacSHA256");
			mac.init(new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
			byte[] hash = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
			return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
		} catch (Exception e) {
			throw new RuntimeException("HMAC SHA256 error", e);
		}
	}

	// 🔎 Helper: Parse JSON string into Map
	private Map<String, Object> parseJson(String json) {
		try {
			return new com.fasterxml.jackson.databind.ObjectMapper().readValue(json, Map.class);
		} catch (Exception e) {
			return Collections.emptyMap();
		}
	}
}
