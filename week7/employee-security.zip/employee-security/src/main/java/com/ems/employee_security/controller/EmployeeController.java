package com.ems.employee_security.controller;

import com.ems.employee_security.model.Employee;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    // ✅ Simulated in-memory database
    private final List<Employee> employees = new ArrayList<>(
            Arrays.asList(
                    new Employee(1L, "Priya", "priya@example.com"),
                    new Employee(2L, "Priyanka", "priyanka@example.com"),
                    new Employee(3L, "Varun", "varun@example.com")
            )
    );

    @GetMapping
    public List<Employee> getEmployees() {
        return employees;
    }

    @PostMapping
    public String addEmployee(@RequestBody Employee employee) {
        employees.add(employee);
        return "Employee added: " + employee.getName();
    }

    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        boolean removed = employees.removeIf(emp -> emp.getId().equals(id));
        return removed ? "Employee removed with ID: " + id : "Employee not found";
    }

    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        return employees.stream()
                .filter(emp -> emp.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Employee not found"));
    }
}