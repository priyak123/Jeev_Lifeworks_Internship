package com.ems.employee_security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeSecurityApplication.class, args);
	}

}
