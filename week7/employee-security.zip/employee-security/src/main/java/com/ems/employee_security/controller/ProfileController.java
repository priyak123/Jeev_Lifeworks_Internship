package com.ems.employee_security.controller;

import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

	@GetMapping
	public String getProfile(Authentication auth) {
		return "Welcome, " + auth.getName();
	}
}
