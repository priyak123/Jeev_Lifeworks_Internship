CREATE TABLE IF NOT EXISTS employees_db (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  department VARCHAR(100),
  position VARCHAR(100),
  salary DOUBLE
);
