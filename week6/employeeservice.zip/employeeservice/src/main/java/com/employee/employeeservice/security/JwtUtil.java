package com.employee.employeeservice.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    private static final String HMAC_ALGO = "HmacSHA256";
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Generates a JWT token for the given username.
     * Only required in User Service.
     */
    public String generateToken(String username) {
        try {
            // Header
            Map<String, Object> header = new HashMap<>();
            header.put("alg", "HS256");
            header.put("typ", "JWT");

            // Payload
            Map<String, Object> payload = new HashMap<>();
            payload.put("sub", username);
            payload.put("iat", System.currentTimeMillis());
            payload.put("exp", System.currentTimeMillis() + 3600000); // 1 hour

            // Encode
            String encodedHeader = base64Encode(objectMapper.writeValueAsString(header));
            String encodedPayload = base64Encode(objectMapper.writeValueAsString(payload));
            String signature = hmacSha256(encodedHeader + "." + encodedPayload, secret);

            return encodedHeader + "." + encodedPayload + "." + signature;

        } catch (Exception e) {
            throw new RuntimeException("JWT generation failed", e);
        }
    }

    /**
     * Validates a token and extracts the username (sub).
     * Used in both services.
     */
    public String validateTokenAndGetUsername(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length != 3) {
                throw new RuntimeException("Invalid JWT format");
            }

            String header = parts[0];
            String payload = parts[1];
            String signature = parts[2];

            // Validate signature
            String expectedSig = hmacSha256(header + "." + payload, secret);
            if (!expectedSig.equals(signature)) {
                throw new RuntimeException("Invalid JWT signature");
            }

            // Decode and parse payload
            String payloadJson = new String(Base64.getUrlDecoder().decode(payload), StandardCharsets.UTF_8);
            Map<String, Object> payloadMap = objectMapper.readValue(payloadJson, Map.class);

            // Validate expiration
            if (!payloadMap.containsKey("exp") || !payloadMap.containsKey("sub")) {
                throw new RuntimeException("Missing required claims");
            }

            long exp = ((Number) payloadMap.get("exp")).longValue();
            if (System.currentTimeMillis() > exp) {
                throw new RuntimeException("Token expired");
            }

            return (String) payloadMap.get("sub");

        } catch (Exception e) {
            throw new RuntimeException("JWT validation failed: " + e.getMessage());
        }
    }

    private String base64Encode(String value) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private String hmacSha256(String data, String secretKey) throws Exception {
        Mac mac = Mac.getInstance(HMAC_ALGO);
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), HMAC_ALGO);
        mac.init(secretKeySpec);
        byte[] hmac = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(hmac);
    }
}