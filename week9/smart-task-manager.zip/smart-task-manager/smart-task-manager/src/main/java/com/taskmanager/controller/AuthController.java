package com.taskmanager.controller;

import com.taskmanager.dto.AuthRequest;
import com.taskmanager.dto.AuthResponse;
import com.taskmanager.dto.ForgotPasswordRequest;
import com.taskmanager.dto.RegisterRequest;
import com.taskmanager.dto.ResetPasswordRequest;
import com.taskmanager.entity.User;
import com.taskmanager.entity.VerificationToken;
import com.taskmanager.repository.UserRepository;
import com.taskmanager.repository.VerificationTokenRepository;
import com.taskmanager.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/api/auth") // Base URL for all auth-related endpoints
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService; // Service containing business logic for auth
    private final VerificationTokenRepository tokenRepository; // To manage email verification tokens
    private final UserRepository userRepository; // To manage user data

    // Endpoint to register a new user
    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
        // Calls service to handle registration and returns message or token
        return authService.register(request);
    }

    // Endpoint to login user and get JWT token
    @PostMapping("/login")
    public AuthResponse login(@RequestBody AuthRequest request) {
        // Calls service to authenticate and generate JWT token in response
        return authService.login(request);
    }

    // Endpoint to verify user's email using a token
    @GetMapping("/verify")
    public ResponseEntity<String> verifyEmail(@RequestParam String token) {
        // Fetch verification token from DB
        VerificationToken vToken = tokenRepository.findByToken(token)
            .orElseThrow(() -> new RuntimeException("Invalid verification token"));
        
        token = token.trim(); // Clean any extra spaces
        
        // Check if token expired
        if (vToken.getExpiryDate().before(new Date())) {
            return ResponseEntity.badRequest().body("Token has expired");
        }

        // Enable the user account after verification
        User user = vToken.getUser();
        user.setEnabled(true);
        userRepository.save(user);

        // Mark token as verified
        vToken.setVerified(true);
        tokenRepository.save(vToken);

        return ResponseEntity.ok("Email verified successfully.");
    }
    
    // Endpoint to request a password reset link via email
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody ForgotPasswordRequest request) {
        // Service sends the reset link to user's email
        authService.sendPasswordResetLink(request.getEmail());
        return ResponseEntity.ok("Reset link sent to email.");
    }

    // Endpoint to reset password using the token and new password
    @PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest request) {
        // Service verifies token and updates the password
        authService.resetPassword(request.getToken(), request.getNewPassword());
        return ResponseEntity.ok("Password has been reset.");
    }

}
