package com.taskmanager.entity;

public enum TaskPriority {
	LOW,
	MEDIUM,
	HIGH

}
