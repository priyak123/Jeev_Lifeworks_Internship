package com.taskmanager.service;

import com.taskmanager.dto.TaskDto;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.entity.TaskPriority;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Service interface for managing tasks including creation,
 * update, deletion, retrieval, and filtering.
 */
public interface TaskService {

    /**
     * Create a new task from the given TaskDto.
     */
    Task createTask(TaskDto dto);

    /**
     * Update an existing task identified by id using TaskDto.
     */
    Task updateTask(Long id, TaskDto dto);

    /**
     * Delete the task by its ID.
     */
    void deleteTask(Long id);

    /**
     * Get all tasks in the system.
     */
    List<Task> getAllTasks();

    /**
     * Get all tasks assigned to a specific user.
     */
    List<Task> getTasksForUser(Long userId);

    /**
     * Get all pending (not completed) tasks for a specific user.
     */
    List<Task> getPendingTasksForUser(Long userId);

    /**
     * Get a count of tasks grouped by their status.
     */
    Map<String, Long> countTasksByStatus();

    /**
     * Get a count of tasks grouped by assigned user.
     */
    Map<String, Long> countTasksByUser();

    /**
     * Filter tasks by status.
     */
    List<Task> filterTasksByStatus(TaskStatus status);

    /**
     * Filter tasks by due date.
     */
    List<Task> filterTasksByDueDate(LocalDate dueDate);

    /**
     * Filter tasks by assignee user ID.
     */
    List<Task> filterTasksByAssignee(Long userId);

    /**
     * Filter tasks by priority.
     */
    List<Task> filterTasksByPriority(TaskPriority priority);

    /**
     * Filter tasks by multiple optional criteria:
     * status, priority, assigneeId, and dueDate.
     */
    List<Task> filterTasks(String status, String priority, Long assigneeId, LocalDate dueDate);
}
