package com.taskmanager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.taskmanager.service.impl.ReminderService;

@RestController
@RequestMapping("/api/reminders") // Base URL for reminder-related endpoints
public class ReminderController {

    @Autowired
    private ReminderService reminderService; // Service to handle reminder logic

    // Endpoint to manually trigger sending daily task reminders
    @GetMapping("/send")
    public ResponseEntity<String> sendReminders() {
        // Calls service method to send reminders
        reminderService.sendDailyTaskReminders();
        return ResponseEntity.ok("Reminders sent successfully");
    }
}
