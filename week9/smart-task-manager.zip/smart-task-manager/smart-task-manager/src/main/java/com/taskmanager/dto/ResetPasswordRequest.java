package com.taskmanager.dto;

import lombok.Data;

@Data
public class ResetPasswordRequest {
    // Token sent to user to verify password reset request
    private String token;

    // New password user wants to set
    private String newPassword;
}
