package com.taskmanager.service.impl;

import com.taskmanager.service.EmailService;
import org.springframework.stereotype.Service;

/**
 * Mock implementation of EmailService for testing and development.
 * Instead of sending real emails, this prints email contents to the console.
 */
@Service
public class MockEmailServiceImpl implements EmailService {

    /**
     * Prints a generic email to the console.
     */
    @Override
    public void sendEmail(String to, String subject, String body) {
        System.out.println("========== MOCK EMAIL ==========");
        System.out.println("To: " + to);
        System.out.println("Subject: " + subject);
        System.out.println("Body:\n" + body);
        System.out.println("================================");
    }

    /**
     * Sends a mock email with an account verification link.
     */
    @Override
    public void sendVerificationEmail(String to, String token) {
        String link = "http://localhost:8080/api/auth/verify?token=" + token;
        String subject = "Email Verification";
        String body = "Click the link to verify your account:\n" + link;
        sendEmail(to, subject, body);
    }

    /**
     * Sends a mock notification email when a new task is assigned.
     */
    @Override
    public void sendTaskAssignedNotification(String to, String taskTitle) {
        String subject = "New Task Assigned";
        String body = "You have been assigned a new task: " + taskTitle;
        sendEmail(to, subject, body);
    }

    /**
     * Sends a mock daily reminder email with a custom message.
     */
    @Override
    public void sendDailyReminder(String to, String message) {
        String subject = "Task Reminder";
        sendEmail(to, subject, message);
    }

    /**
     * Sends a mock password reset email with a reset link.
     */
    @Override
    public void sendResetPasswordLink(String to, String token) {
        String resetLink = "http://localhost:4200/reset-password?token=" + token;
        String subject = "Reset Your Password";
        String body = "Click the link to reset your password:\n" + resetLink;
        sendEmail(to, subject, body);
    }
}
