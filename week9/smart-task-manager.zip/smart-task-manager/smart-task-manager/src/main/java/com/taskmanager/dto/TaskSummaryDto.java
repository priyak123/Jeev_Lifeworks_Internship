package com.taskmanager.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Lombok Annotations used:
 * 
 * @Data - Generates getters, setters, toString(), equals(), and hashCode() methods automatically.
 * @AllArgsConstructor - Generates a constructor with parameters for all fields.
 * @NoArgsConstructor - Generates a default no-argument constructor.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskSummaryDto {
    private long totalTasks;
    private long completedTasks;
    private long inProgressTasks;
    private long todoTasks;
    private long overdueTasks;
    private long pendingTasks;
}
