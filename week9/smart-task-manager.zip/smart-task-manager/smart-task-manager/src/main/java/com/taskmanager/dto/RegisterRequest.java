package com.taskmanager.dto;

import com.taskmanager.entity.Role;
import lombok.Data;

@Data
public class RegisterRequest {
    // Full name of the user registering
    private String fullName;

    // Email address of the new user
    private String email;

    // Password chosen by the user
    private String password;

    // Role assigned to the user (e.g., ADMIN, MANAGER, EMPLOYEE)
    private Role role;
}
