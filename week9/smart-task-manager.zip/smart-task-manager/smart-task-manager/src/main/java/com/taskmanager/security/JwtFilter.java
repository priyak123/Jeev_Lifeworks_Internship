package com.taskmanager.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

@Component  // Marks this as a Spring-managed bean
@RequiredArgsConstructor  // Injects final fields via constructor
public class JwtFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;  // Utility class for JWT operations (validate, extract claims)
    private final UserDetailsService userDetailsService;  // Not used here but available for future

    /**
     * This method is called once per request to inspect the Authorization header,
     * validate the JWT token, and set the authentication context if valid.
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain)
            throws ServletException, IOException {

        // Get Authorization header from the request
        String authHeader = request.getHeader("Authorization");

        // Check if the header is present and starts with "Bearer "
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            // Extract JWT token by removing "Bearer " prefix
            String token = authHeader.substring(7);

            // Validate the token (expiry, signature, etc.)
            if (jwtUtil.validateToken(token)) {
                // Extract user email and role from the token claims
                String email = jwtUtil.extractEmail(token);
                String role = jwtUtil.extractRole(token);

                // Create authentication token with email as principal and role as authority
                UsernamePasswordAuthenticationToken authenticationToken =
                        new UsernamePasswordAuthenticationToken(
                                email,  // principal (user identity)
                                null,   // credentials not required here
                                Collections.singletonList(new SimpleGrantedAuthority(role))  // granted authorities
                        );

                // Set the authentication in the SecurityContext
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            }
        }

        // Continue the filter chain (allow the request to proceed)
        chain.doFilter(request, response);
    }
}
