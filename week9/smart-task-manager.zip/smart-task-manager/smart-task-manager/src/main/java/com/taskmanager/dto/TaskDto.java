package com.taskmanager.dto;

import com.taskmanager.entity.TaskPriority;
import com.taskmanager.entity.TaskStatus;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskDto {

    @NotBlank(message = "Title is mandatory")
    private String title;  // Task title, cannot be blank

    @NotBlank(message = "Description is mandatory")
    private String description;  // Task description, cannot be blank

    @NotNull(message = "Status is required")
    private TaskStatus status;  // Task status (e.g., PENDING, COMPLETED), must be provided

    @Future(message = "Due date must be in the future")
    @NotNull(message = "Due date is required")
    private LocalDate dueDate;  // Task due date, must be future date and not null

    @NotNull(message = "Assigned user is required")
    private Long assignedToUserId;  // ID of the user assigned to this task, cannot be null
    
    private TaskPriority priority;  // Task priority (e.g., HIGH, MEDIUM, LOW), optional

}
