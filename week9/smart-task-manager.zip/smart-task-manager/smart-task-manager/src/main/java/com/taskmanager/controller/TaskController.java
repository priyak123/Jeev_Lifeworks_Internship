package com.taskmanager.controller;

import com.taskmanager.dto.TaskDto;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskPriority;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.service.TaskService;
import lombok.RequiredArgsConstructor;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import org.springframework.format.annotation.DateTimeFormat;

@RestController
@RequestMapping("/api/tasks")  // Base URL for task-related endpoints
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;  // Service layer to handle business logic

    // Create a new task (only ADMIN and MANAGER can do this)
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @PostMapping
    public Task createTask(@RequestBody TaskDto dto) {
        return taskService.createTask(dto);
    }

    // Update an existing task by ID (only ADMIN and MANAGER)
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @PutMapping("/{id}")
    public Task updateTask(@PathVariable Long id, @RequestBody TaskDto dto) {
        return taskService.updateTask(id, dto);
    }

    // Delete a task by ID (only ADMIN)
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
        return ResponseEntity.ok(Map.of("message", "Task deleted successfully"));
    }

    // Get list of all tasks (no role restriction)
    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    // Get all tasks assigned to a specific user
    @GetMapping("/user/{userId}")
    public List<Task> getTasksForUser(@PathVariable Long userId) {
        return taskService.getTasksForUser(userId);
    }
    
    // Get count of tasks grouped by status (only ADMIN and MANAGER)
    @GetMapping("/stats/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public Map<String, Long> getTaskCountByStatus() {
        return taskService.countTasksByStatus();
    }

    // Get count of tasks grouped by user (only ADMIN and MANAGER)
    @GetMapping("/stats/user")
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    public Map<String, Long> getTaskCountByUser() {
        return taskService.countTasksByUser();
    }

    // Get pending tasks for a user (ADMIN, MANAGER, and EMPLOYEE roles allowed)
    @GetMapping("/user/{userId}/pending")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYEE')")
    public List<Task> getPendingTasks(@PathVariable Long userId) {
        return taskService.getPendingTasksForUser(userId);
    }

    // Filter tasks by multiple optional parameters: status, priority, assignee, due date
    @GetMapping("/filter")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<List<Task>> filterTasks(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String priority,
            @RequestParam(required = false) Long assigneeId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dueDate) {

        List<Task> filteredTasks = taskService.filterTasks(status, priority, assigneeId, dueDate);
        return ResponseEntity.ok(filteredTasks);
    }

    // Filter tasks by status only
    @GetMapping("/filter/status")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Task> filterByStatus(@RequestParam TaskStatus status) {
        return taskService.filterTasksByStatus(status);
    }

    // Filter tasks by due date only
    @GetMapping("/filter/due-date")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Task> filterByDueDate(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        return taskService.filterTasksByDueDate(date);
    }

    // Filter tasks by assignee (user)
    @GetMapping("/filter/assignee")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Task> filterByAssignee(@RequestParam Long userId) {
        return taskService.filterTasksByAssignee(userId);
    }

    // Filter tasks by priority
    @GetMapping("/filter/priority")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public List<Task> filterByPriority(@RequestParam TaskPriority priority) {
        return taskService.filterTasksByPriority(priority);
    }

}
