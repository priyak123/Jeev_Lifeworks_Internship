package com.taskmanager.repository;

import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskPriority;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    // Count tasks by a specific status
    long countByStatus(TaskStatus status);

    // Count tasks overdue and not completed as of today
    @Query("SELECT COUNT(t) FROM Task t WHERE t.dueDate < :today AND t.status <> com.taskmanager.entity.TaskStatus.COMPLETED")
    long countOverdueTasks(@Param("today") LocalDate today);

    // Find all tasks assigned to a specific user entity
    List<Task> findByAssignedTo(User user);

    // Find tasks by status and assigned user
    List<Task> findByStatusAndAssignedTo(TaskStatus status, User user);

    // Find tasks overdue and not completed on or before a given date
    @Query("SELECT t FROM Task t WHERE t.dueDate <= :dueDate AND t.status <> 'COMPLETED'")
    List<Task> findOverdueTasks(@Param("dueDate") LocalDate dueDate);

    // Count tasks assigned to a specific user
    long countByAssignedTo(User user);

    // Group count of tasks by status (returns List of [TaskStatus, count])
    @Query("SELECT t.status, COUNT(t) FROM Task t GROUP BY t.status")
    List<Object[]> countTasksByStatus();

    // Group count of completed tasks by employee name
    @Query("SELECT t.assignedTo.fullName, COUNT(t) FROM Task t WHERE t.status = com.taskmanager.entity.TaskStatus.COMPLETED GROUP BY t.assignedTo.fullName")
    List<Object[]> countCompletedTasksByEmployee();

    // Find tasks with due date before a date and not completed
    List<Task> findByDueDateBeforeAndStatusNot(LocalDate date, TaskStatus status);

    // Find tasks with due date equal to a date and not completed
    List<Task> findByDueDateAndStatusNot(LocalDate date, TaskStatus status);

    // ===========================
    // Filtering Support Methods
    // ===========================

    // 1. Filter by Status
    List<Task> findByStatus(TaskStatus status);

    // 2. Filter by Due Date
    List<Task> findByDueDate(LocalDate dueDate);

    // 3. Filter by Assignee ID
    List<Task> findByAssignedTo_Id(Long userId);

    // 4. Filter by Priority
    List<Task> findByPriority(TaskPriority priority);

    // 5. Filter by Status and Assignee ID
    List<Task> findByStatusAndAssignedTo_Id(TaskStatus status, Long userId);

    // 6. Filter by Priority and Due Date
    List<Task> findByPriorityAndDueDate(TaskPriority priority, LocalDate dueDate);

    // 7. Complex Filter with optional parameters
    @Query("SELECT t FROM Task t WHERE "
         + "(:status IS NULL OR t.status = :status) AND "
         + "(:priority IS NULL OR t.priority = :priority) AND "
         + "(:assigneeId IS NULL OR t.assignedTo.id = :assigneeId) AND "
         + "(:dueDate IS NULL OR t.dueDate = :dueDate)")
    List<Task> filterTasks(
         @Param("status") TaskStatus status,
         @Param("priority") TaskPriority priority,
         @Param("assigneeId") Long assigneeId,
         @Param("dueDate") LocalDate dueDate
    );

    // Alternative method: find by assignee ID (same as findByAssignedTo_Id)
    List<Task> findByAssignedToId(Long userId);
}
