package com.taskmanager.service;

import com.taskmanager.dto.AuthRequest;
import com.taskmanager.dto.AuthResponse;
import com.taskmanager.dto.RegisterRequest;

public interface AuthService {

    /**
     * Registers a new user with the given registration details.
     * Returns a success message or error.
     */
    String register(RegisterRequest request);

    /**
     * Authenticates a user with email and password.
     * Returns an AuthResponse containing a JWT token if successful.
     */
    AuthResponse login(AuthRequest request);

    /**
     * Sends a password reset link to the specified email address.
     */
    void sendPasswordResetLink(String email);

    /**
     * Resets the user's password using a valid reset token.
     */
    void resetPassword(String token, String newPassword);
}
