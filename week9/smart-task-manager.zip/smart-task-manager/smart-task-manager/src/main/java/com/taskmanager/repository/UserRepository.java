package com.taskmanager.repository;

import com.taskmanager.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    // Find a user by their unique email address
    Optional<User> findByEmail(String email);

    // Find a user by their password reset token
    Optional<User> findByResetToken(String token);

    // Check if a user with the given email already exists (returns true/false)
    boolean existsByEmail(String email);
}
