package com.taskmanager.service;

/**
 * Service interface for sending various types of emails.
 */
public interface EmailService {

    /**
     * Sends an email containing a verification link with the given token.
     * Used during user registration to verify email address.
     */
    void sendVerificationEmail(String to, String token);

    /**
     * Sends a general-purpose email with subject and body.
     */
    void sendEmail(String to, String subject, String body);

    /**
     * Sends a notification email to inform user about a newly assigned task.
     */
    void sendTaskAssignedNotification(String to, String taskTitle);

    /**
     * Sends a daily reminder email with a custom message.
     */
    void sendDailyReminder(String to, String message);

    /**
     * Sends an email with a password reset link containing the token.
     */
    void sendResetPasswordLink(String to, String token);
}
