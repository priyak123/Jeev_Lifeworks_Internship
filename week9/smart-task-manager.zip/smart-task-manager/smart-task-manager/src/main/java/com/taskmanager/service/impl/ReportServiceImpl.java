package com.taskmanager.service.impl;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.taskmanager.dto.TaskSummaryDto;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.ReportService;
import lombok.RequiredArgsConstructor;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Implementation of ReportService to generate task summary reports
 * in PDF and Excel formats and provide task summary data.
 */
@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final TaskRepository taskRepository;

    /**
     * Fetches summary statistics of tasks from the database.
     * Counts total, completed, in-progress, todo, overdue, and pending tasks.
     *
     * @return TaskSummaryDto containing task counts by status.
     */
    @Override
    public TaskSummaryDto getTaskSummary() {
        long total = taskRepository.count();
        long completed = taskRepository.countByStatus(TaskStatus.COMPLETED);
        long inProgress = taskRepository.countByStatus(TaskStatus.IN_PROGRESS);
        long todo = taskRepository.countByStatus(TaskStatus.TODO);
        long overdue = taskRepository.countOverdueTasks(LocalDate.now());
        long pending1 = taskRepository.countByStatus(TaskStatus.BLOCKED); // Using BLOCKED as pending

        return new TaskSummaryDto(total, completed, inProgress, todo, overdue, pending1);
    }

    /**
     * Generates a PDF report of task summary.
     *
     * @return byte array of the generated PDF document.
     */
    @Override
    public byte[] generateSummaryPdf() {
        TaskSummaryDto summary = getTaskSummary();

        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();

            // Add centered title with larger font size
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph title = new Paragraph("Task Summary Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20);
            document.add(title);

            // Create a table with 2 columns: Metric and Value
            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10);

            // Add rows for different task counts
            addTableRow(table, "Total Tasks", String.valueOf(summary.getTotalTasks()));
            addTableRow(table, "Completed Tasks", String.valueOf(summary.getCompletedTasks()));
            addTableRow(table, "In-Progress Tasks", String.valueOf(summary.getInProgressTasks()));
            addTableRow(table, "Pending Tasks", String.valueOf(summary.getPendingTasks()));

            document.add(table);
            document.close();

            return out.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }
    }

    /**
     * Helper method to add a row to the PDF table.
     *
     * @param table PdfPTable to add the row to.
     * @param label The metric name.
     * @param value The metric value.
     */
    private void addTableRow(PdfPTable table, String label, String value) {
        PdfPCell cell1 = new PdfPCell(new Phrase(label));
        PdfPCell cell2 = new PdfPCell(new Phrase(value));
        table.addCell(cell1);
        table.addCell(cell2);
    }

    /**
     * Generates an Excel report of task summary using Apache POI.
     *
     * @return byte array of the generated Excel file.
     */
    @Override
    public byte[] generateSummaryExcel() {
        TaskSummaryDto summary = getTaskSummary();

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = workbook.createSheet("Task Summary");

            // Header row
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Metric");
            header.createCell(1).setCellValue("Value");

            int rowNum = 1;

            // Add data rows with metric names and values
            Row row1 = sheet.createRow(rowNum++);
            row1.createCell(0).setCellValue("Total Tasks");
            row1.createCell(1).setCellValue(summary.getTotalTasks());

            Row row2 = sheet.createRow(rowNum++);
            row2.createCell(0).setCellValue("Completed Tasks");
            row2.createCell(1).setCellValue(summary.getCompletedTasks());

            Row row3 = sheet.createRow(rowNum++);
            row3.createCell(0).setCellValue("In Progress Tasks");
            row3.createCell(1).setCellValue(summary.getInProgressTasks());

            Row row4 = sheet.createRow(rowNum++);
            row4.createCell(0).setCellValue("Todo Tasks");
            row4.createCell(1).setCellValue(summary.getTodoTasks());

            Row row5 = sheet.createRow(rowNum++);
            row5.createCell(0).setCellValue("Pending Tasks");
            row5.createCell(1).setCellValue(summary.getPendingTasks());

            Row row6 = sheet.createRow(rowNum++);
            row6.createCell(0).setCellValue("Overdue Tasks");
            row6.createCell(1).setCellValue(summary.getOverdueTasks());

            workbook.write(out);
            return out.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate Excel report", e);
        }
    }

    /**
     * Retrieves a map of employee names to the count of their completed tasks.
     *
     * @return Map with key as employee full name, value as count of completed tasks.
     */
    @Override
    public Map<String, Long> getCompletedTasksByEmployee() {
        List<Object[]> result = taskRepository.countCompletedTasksByEmployee();
        return result.stream()
                .collect(Collectors.toMap(
                        row -> (String) row[0],
                        row -> (Long) row[1]
                ));
    }
}
