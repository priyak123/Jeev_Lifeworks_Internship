package com.taskmanager.controller;

import com.taskmanager.entity.TaskStatus;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.ChartService;
import com.taskmanager.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/charts") // Base URL for chart/report related endpoints
@RequiredArgsConstructor
public class ReportChartController {

    private final TaskRepository taskRepository; // To get task data from DB
    private final ChartService chartService;     // Service to generate chart images
    private final TaskService taskService;       // Service for task-related business logic

    /**
     * Endpoint to get a pie chart image of task status distribution.
     * The pie chart shows how many tasks are in each status.
     */
    @GetMapping(value = "/task-status", produces = MediaType.IMAGE_PNG_VALUE)
    public @ResponseBody byte[] getTaskStatusChart() throws IOException {
        // Fetch count of tasks grouped by status from repository
        List<Object[]> result = taskRepository.countTasksByStatus();

        // Prepare pie chart dataset
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Object[] obj : result) {
            TaskStatus status = (TaskStatus) obj[0];
            Long count = (Long) obj[1];
            dataset.setValue(status.name(), count);
        }

        // Create pie chart with JFreeChart
        JFreeChart chart = ChartFactory.createPieChart(
                "Task Status Distribution", // chart title
                dataset,
                true,  // include legend
                true,  // tooltips
                false  // URLs
        );

        // Convert chart to PNG image bytes
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        ChartUtils.writeChartAsPNG(outputStream, chart, 600, 400);
        return outputStream.toByteArray();
    }

    /**
     * Endpoint to get a bar chart image showing number of tasks per user.
     * Delegates chart creation to ChartService.
     */
    @GetMapping(value = "/task-count-bar", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getTaskCountBarChart() {
        // Get task counts grouped by user from TaskService
        byte[] image = chartService.generateTaskCountBarChart(taskService.countTasksByUser());

        // Return the PNG image in the response with appropriate content type
        return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_PNG)
                .body(image);
    }
}
