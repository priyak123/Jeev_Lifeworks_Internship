package com.taskmanager.entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "users")  // Specifies table name; optional, defaults to class name if omitted
@Getter  // Lombok generates getters for all fields
@Setter  // Lombok generates setters for all fields
@NoArgsConstructor  // Lombok generates a no-argument constructor
public class User {

    @Id  // Primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment primary key
    private Long id;

    private String fullName;  // User's full name

    @Column(unique = true, nullable = false)  // Unique and not-null email column
    private String email;

    @Column(nullable = false)  // Password column must not be null
    private String password;

    @Enumerated(EnumType.STRING)  // Store enum as string in DB
    @Column(nullable = false)
    private Role role;  // User role (e.g., ADMIN, MANAGER, EMPLOYEE)

    private boolean enabled = false;  // Whether user account is enabled

    @Column(name = "email_verified", nullable = false)
    private boolean emailVerified = false;  // Whether email is verified

    @Column(name = "reset_token")
    private String resetToken;  // Token for password reset

    @Column(name = "reset_token_expiry")
    private LocalDateTime resetTokenExpiry;  // Expiry date/time for reset token

    // Convenience constructor for creating a new user with required fields
    public User(String fullName, String email, String password, Role role) {
        this.fullName = fullName;
        this.email = email;
        this.password = password;
        this.role = role;
        this.enabled = false;
        this.emailVerified = false;
    }

}
