package com.taskmanager.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.taskmanager.entity.Task;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.service.EmailService;

import lombok.RequiredArgsConstructor;

/**
 * Service responsible for sending daily task reminder emails
 * for tasks that are overdue or due soon.
 */
@Service
@RequiredArgsConstructor
public class ReminderService {

    private final TaskRepository taskRepository;
    private final EmailService emailService;

    /**
     * Scheduled method that runs every day at 9 AM to send reminder emails.
     * It fetches tasks that are overdue or due soon and sends email notifications
     * to the assigned users.
     */
    @Scheduled(cron = "0 0 9 * * *") // Executes daily at 9 AM
    public void sendDailyTaskReminders() {
        LocalDate today = LocalDate.now();

        // Retrieve tasks which are overdue or not completed by today
        List<Task> tasks = taskRepository.findOverdueTasks(today);

        for (Task task : tasks) {
            // Skip tasks with empty or null titles
            if (task.getTitle() == null || task.getTitle().trim().isEmpty()) {
                System.out.println("Skipping task with empty title: ID=" + task.getId());
                continue;
            }

            String to = task.getAssignedTo().getEmail();
            String subject = "Task Reminder: " + task.getTitle();
            String body = "Reminder: Task '" + task.getTitle() + "' is due soon.";

            System.out.println("Found task for reminder: ID=" + task.getId() + ", Title=" + task.getTitle());

            // Send reminder email using the EmailService
            emailService.sendEmail(to, subject, body);
        }
    }
}
