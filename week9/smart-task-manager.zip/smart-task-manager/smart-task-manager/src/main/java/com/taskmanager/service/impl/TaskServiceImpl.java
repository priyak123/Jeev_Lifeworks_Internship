package com.taskmanager.service.impl;

import com.taskmanager.dto.TaskDto;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskPriority;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.entity.User;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.repository.UserRepository;
import com.taskmanager.service.EmailService;
import com.taskmanager.service.TaskService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final EmailService emailService;

    /**
     * Creates a new task and assigns it to a user.
     * Sends email notification to the assigned user.
     *
     * @param dto Task data transfer object with task details and assigned user ID
     * @return the saved Task entity
     * @throws IllegalArgumentException if assigned user ID is null
     * @throws RuntimeException if user is not found
     */
    @Override
    public Task createTask(TaskDto dto) {
        if (dto.getAssignedToUserId() == null) {
            throw new IllegalArgumentException("Assigned user ID must not be null");
        }

        // Find assigned user by ID or throw if not found
        User assignedTo = userRepository.findById(dto.getAssignedToUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Build new Task entity
        Task task = Task.builder()
                .title(dto.getTitle())
                .description(dto.getDescription())
                .status(dto.getStatus())
                .dueDate(dto.getDueDate())
                .assignedTo(assignedTo)
                .priority(dto.getPriority())
                .build();

        // Save task in DB
        Task savedTask = taskRepository.save(task);

        // Send notification email about new task assignment
        emailService.sendEmail(
            assignedTo.getEmail(),
            "New Task Assigned",
            "You have been assigned a new task: " + savedTask.getTitle()
        );

        return savedTask;  // Return saved task entity
    }

    /**
     * Updates an existing task by its ID with new values from DTO.
     *
     * @param id task ID to update
     * @param dto DTO containing updated task details
     * @return updated Task entity
     * @throws RuntimeException if task or assigned user not found
     */
    @Override
    public Task updateTask(Long id, TaskDto dto) {
        // Find existing task or throw if not found
        Task task = taskRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Task not found"));

        // Update task fields
        task.setTitle(dto.getTitle());
        task.setDescription(dto.getDescription());
        task.setStatus(dto.getStatus());
        task.setDueDate(dto.getDueDate());
        task.setPriority(dto.getPriority());  // Update priority

        // If assigned user ID is provided, update the assigned user
        if (dto.getAssignedToUserId() != null) {
            User assignedTo = userRepository.findById(dto.getAssignedToUserId())
                    .orElseThrow(() -> new RuntimeException("User not found"));
            task.setAssignedTo(assignedTo);
        }

        return taskRepository.save(task);  // Save and return updated task
    }

    /**
     * Deletes a task by its ID.
     *
     * @param id ID of the task to delete
     */
    @Override
    public void deleteTask(Long id) {
        taskRepository.deleteById(id);
    }

    /**
     * Retrieves all tasks from the repository.
     *
     * @return list of all tasks
     */
    @Override
    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    /**
     * Retrieves all tasks assigned to a specific user.
     *
     * @param userId ID of the user
     * @return list of tasks assigned to the user
     * @throws RuntimeException if user not found
     */
    @Override
    public List<Task> getTasksForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return taskRepository.findByAssignedTo(user);
    }

    /**
     * Counts tasks grouped by their status.
     *
     * @return map of status name to count
     */
    @Override
    public Map<String, Long> countTasksByStatus() {
        return taskRepository.findAll().stream()
                .collect(Collectors.groupingBy(
                        task -> task.getStatus().name(),
                        Collectors.counting()
                ));
    }

    /**
     * Counts tasks grouped by assigned user's full name.
     *
     * @return map of user full name to count of tasks assigned
     */
    @Override
    public Map<String, Long> countTasksByUser() {
        return taskRepository.findAll().stream()
                .collect(Collectors.groupingBy(
                        task -> task.getAssignedTo().getFullName(),
                        Collectors.counting()
                ));
    }

    /**
     * Retrieves all tasks for a user that are currently pending.
     *
     * @param userId ID of the user
     * @return list of pending tasks for the user
     * @throws RuntimeException if user not found
     */
    @Override
    public List<Task> getPendingTasksForUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        return taskRepository.findByStatusAndAssignedTo(TaskStatus.PENDING, user);
    }

    /**
     * Filters tasks based on multiple optional parameters.
     *
     * @param status    status string filter, can be null
     * @param priority  priority string filter, can be null
     * @param assigneeId user ID to filter tasks assigned to, can be null
     * @param dueDate   due date filter, can be null
     * @return filtered list of tasks
     */
    @Override
    public List<Task> filterTasks(String status, String priority, Long assigneeId, LocalDate dueDate) {
        return taskRepository.findAll().stream()
                .filter(task -> status == null || task.getStatus().name().equalsIgnoreCase(status))
                .filter(task -> priority == null || (task.getPriority() != null && task.getPriority().name().equalsIgnoreCase(priority)))
                .filter(task -> assigneeId == null || (task.getAssignedTo() != null && task.getAssignedTo().getId().equals(assigneeId)))
                .filter(task -> dueDate == null || (task.getDueDate() != null && task.getDueDate().equals(dueDate)))
                .collect(Collectors.toList());
    }

    /**
     * Filters tasks by exact status.
     *
     * @param status status enum
     * @return list of tasks matching the status
     */
    @Override
    public List<Task> filterTasksByStatus(TaskStatus status) {
        return taskRepository.findByStatus(status);
    }

    /**
     * Filters tasks by due date.
     *
     * @param dueDate due date to filter by
     * @return list of tasks due on that date
     */
    @Override
    public List<Task> filterTasksByDueDate(LocalDate dueDate) {
        return taskRepository.findByDueDate(dueDate);
    }

    /**
     * Filters tasks assigned to a specific user.
     *
     * @param userId user ID
     * @return list of tasks assigned to the user
     * @throws RuntimeException if user not found
     */
    @Override
    public List<Task> filterTasksByAssignee(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return taskRepository.findByAssignedTo(user);
    }

    /**
     * Filters tasks by priority.
     *
     * @param priority priority enum
     * @return list of tasks matching the priority
     */
    @Override
    public List<Task> filterTasksByPriority(TaskPriority priority) {
        return taskRepository.findByPriority(priority);
    }
}
