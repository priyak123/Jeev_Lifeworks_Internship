package com.taskmanager.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity  // Marks this class as a JPA entity mapped to a database table
@Getter  // Lombok generates getter methods for all fields
@Setter  // Lombok generates setter methods for all fields
@NoArgsConstructor  // Lombok generates a no-args constructor
@AllArgsConstructor  // Lombok generates an all-args constructor
@Builder  // Lombok enables builder pattern for easy object creation
public class Task {

    @Id  // Primary key of the entity
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment strategy for PK
    private Long id;

    private String title;  // Task title

    @Column(length = 1000)  // Description column with max length 1000 chars
    private String description;

    @Enumerated(EnumType.STRING)  // Store enum as String in DB for readability
    private TaskStatus status;  // Task status (e.g., TO_DO, IN_PROGRESS, BLOCKED, COMPLETED)

    @Enumerated(EnumType.STRING)
    @Column(name = "priority")  // Explicit column name "priority"
    private TaskPriority priority;  // Task priority (LOW, MEDIUM, HIGH)

    private LocalDate dueDate;  // Task due date

    @ManyToOne  // Many tasks can be assigned to one User
    @JoinColumn(name = "assigned_to")  // Foreign key column name in task table
    private User assignedTo;  // User entity this task is assigned to
}
