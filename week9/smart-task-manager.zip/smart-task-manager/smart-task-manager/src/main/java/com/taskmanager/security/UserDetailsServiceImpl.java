package com.taskmanager.security;

import com.taskmanager.entity.User;
import com.taskmanager.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service  // Marks this as a Spring service bean
@RequiredArgsConstructor  // Inject UserRepository via constructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * Loads a user by email (username) for Spring Security authentication.
     * Throws UsernameNotFoundException if user not found.
     * Returns a UserDetails object containing email, password, enabled status, and authorities.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        // Build UserDetails object expected by Spring Security
        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),            // username
                user.getPassword(),         // password hash
                user.isEnabled(),           // enabled: true if email verified and account enabled
                true,                      // accountNonExpired
                true,                      // credentialsNonExpired
                true,                      // accountNonLocked
                Collections.singletonList(new SimpleGrantedAuthority(user.getRole().name())) // roles/authorities
        );
    }
}
