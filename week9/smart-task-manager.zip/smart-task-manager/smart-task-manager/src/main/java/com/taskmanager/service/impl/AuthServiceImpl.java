package com.taskmanager.service.impl;

import com.taskmanager.dto.RegisterRequest;
import com.taskmanager.dto.AuthRequest;
import com.taskmanager.dto.AuthResponse;
import com.taskmanager.entity.User;
import com.taskmanager.entity.VerificationToken;
import com.taskmanager.repository.UserRepository;
import com.taskmanager.repository.VerificationTokenRepository;
import com.taskmanager.security.JwtUtil;
import com.taskmanager.service.AuthService;
import com.taskmanager.service.EmailService;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

/**
 * Marks the class as a Spring service component.
 * Enables automatic detection and registration of this class as a service bean.
 */
@Service

/**
 * Lombok annotation to generate a constructor with required (final) fields.
 * Helps in dependency injection by creating a constructor for all final fields.
 */
@RequiredArgsConstructor

public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final VerificationTokenRepository tokenRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    /**
     * Registers a new user with provided details.
     *  - Checks if email is already registered.
     *  - Encrypts password.
     *  - Creates a verification token valid for 24 hours.
     *  - Sends verification email with the token.
     *
     * @param request RegisterRequest containing fullName, email, password, and role.
     * @return Success message.
     * @throws RuntimeException if email already exists.
     */
    @Override
    public String register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        // Create and save user with encrypted password and disabled status
        User user = new User();
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());
        user.setEnabled(false);          // Disabled until email verification
        user.setEmailVerified(false);

        userRepository.save(user);

        // Generate verification token and save it
        String token = UUID.randomUUID().toString();
        VerificationToken verificationToken = new VerificationToken();
        verificationToken.setToken(token);
        verificationToken.setUser(user);
        verificationToken.setExpiryDate(new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000)); // 24 hours expiry
        verificationToken.setVerified(false);
        tokenRepository.save(verificationToken);

        // Send verification email to user with the token
        emailService.sendVerificationEmail(user.getEmail(), token);

        return "Registration successful. Please verify your email.";
    }

    /**
     * Authenticates a user using email and password.
     *  - Validates if the user exists.
     *  - Checks if email is verified (enabled).
     *  - Validates password against encrypted password.
     *  - Generates JWT token if authentication is successful.
     *
     * @param request AuthRequest with email and password.
     * @return AuthResponse containing JWT token.
     * @throws RuntimeException if authentication fails.
     */
    @Override
    public AuthResponse login(AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email"));

        if (!user.isEnabled()) {
            throw new RuntimeException("Email not verified");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        String jwt = jwtUtil.generateToken(user);
        return new AuthResponse(jwt);
    }

    /**
     * Sends a password reset link to the user email.
     *  - Generates a reset token valid for 30 minutes.
     *  - Saves reset token and expiry in user record.
     *  - Sends an email containing the reset password link with token.
     *
     * @param email User's registered email address.
     * @throws RuntimeException if user with the email does not exist.
     */
    @Override
    public void sendPasswordResetLink(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        String token = UUID.randomUUID().toString();
        user.setResetToken(token);
        user.setResetTokenExpiry(LocalDateTime.now().plusMinutes(30)); // Token valid for 30 minutes
        userRepository.save(user);

        String resetLink = "http://localhost:4200/reset-password?token=" + token;
        String body = "Click here to reset your password:\n" + resetLink;

        emailService.sendEmail(user.getEmail(), "Reset Password", body);
    }

    /**
     * Resets the user's password given a valid reset token and new password.
     *  - Validates the token exists and is not expired.
     *  - Updates password with encrypted new password.
     *  - Clears reset token and expiry after successful reset.
     *
     * @param token Reset token from the reset link.
     * @param newPassword New password to set.
     * @throws RuntimeException if token is invalid or expired.
     */
    @Override
    public void resetPassword(String token, String newPassword) {
        User user = userRepository.findByResetToken(token)
                .orElseThrow(() -> new RuntimeException("Invalid token"));

        if (user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token expired");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        user.setResetToken(null);
        user.setResetTokenExpiry(null);
        userRepository.save(user);
    }
}
