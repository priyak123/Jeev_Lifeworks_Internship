package com.taskmanager.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.taskmanager.entity.User;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component  // Spring-managed bean for JWT utility methods
public class JwtUtil {

    private final String SECRET = "smart_task_secret";  // Secret key for signing the token
    private final long EXPIRATION = 60 * 60 * 1000;     // Token validity period (1 hour in milliseconds)

    /**
     * Generates a JWT token for the given user.
     * Includes email as subject and role as a custom claim.
     * Sets issued and expiration timestamps.
     */
    public String generateToken(User user) {
        return JWT.create()
                .withSubject(user.getEmail())                 // Use email as subject
                .withClaim("role", user.getRole().name())    // Add role claim
                .withIssuedAt(new Date())                     // Token issued time
                .withExpiresAt(new Date(System.currentTimeMillis() + EXPIRATION))  // Expiry time
                .sign(Algorithm.HMAC256(SECRET));            // Sign with HMAC SHA-256 and secret key
    }

    /**
     * Extracts the email (subject) from the JWT token.
     */
    public String extractEmail(String token) {
        return JWT.require(Algorithm.HMAC256(SECRET))
                .build()
                .verify(token)  // Verify signature and validity
                .getSubject();  // Extract subject (email)
    }

    /**
     * Extracts the role claim from the JWT token.
     */
    public String extractRole(String token) {
        return JWT.require(Algorithm.HMAC256(SECRET))
                .build()
                .verify(token)
                .getClaim("role")
                .asString();    // Get role claim as String
    }

    /**
     * Validates the token's signature and expiry.
     * Returns true if valid, false otherwise.
     */
    public boolean validateToken(String token) {
        try {
            JWT.require(Algorithm.HMAC256(SECRET))
               .build()
               .verify(token);
            return true;
        } catch (Exception e) {
            return false;  // Invalid signature or token expired
        }
    }
}
