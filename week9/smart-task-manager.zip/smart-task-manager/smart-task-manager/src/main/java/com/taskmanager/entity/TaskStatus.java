package com.taskmanager.entity;

public enum TaskStatus {
    TODO,
    IN_PROGRESS,
    COMPLETED,
    PENDING, 
    BLOCKED
}
