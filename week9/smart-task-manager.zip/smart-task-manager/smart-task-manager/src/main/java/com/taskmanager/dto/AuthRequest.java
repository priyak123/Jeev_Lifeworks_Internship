package com.taskmanager.dto;

import lombok.Data;

@Data
public class AuthRequest {
    // User's email for login
    private String email;

    // User's password for login
    private String password;
}
