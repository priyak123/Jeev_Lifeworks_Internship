package com.taskmanager.service;

import com.taskmanager.dto.TaskSummaryDto;

/**
 * Service interface for generating task summary reports.
 */
public interface ServiceReport {

    /**
     * Retrieves a summary of tasks including counts like total, completed, pending, etc.
     * 
     * @return TaskSummaryDto containing summarized task data.
     */
    TaskSummaryDto getTaskSummary();
}
