package com.taskmanager.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity  // Marks this class as a JPA entity mapped to a database table
@Getter  // Lombok generates getter methods for all fields
@Setter  // Lombok generates setter methods for all fields
@NoArgsConstructor  // Lombok generates a no-args constructor
@AllArgsConstructor  // Lombok generates an all-args constructor
@Builder  // Lombok enables builder pattern for easy object creation
public class VerificationToken {

    @Id  // Primary key of the entity
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment strategy for PK
    private Long id;

    @Column(nullable = false, unique = true)  // Token string must be unique and not null
    private String token;

    @OneToOne(fetch = FetchType.LAZY)  // One-to-one relationship with User entity; lazy loading
    @JoinColumn(name = "user_id", nullable = false)  // Foreign key column "user_id"
    private User user;

    @Temporal(TemporalType.TIMESTAMP)  // Store Date as timestamp (date + time)
    @Column(nullable = false)  // Expiry date must not be null
    private Date expiryDate;

    @Column(nullable = false)  // Indicates if the token has been verified
    private boolean verified = false;
}
