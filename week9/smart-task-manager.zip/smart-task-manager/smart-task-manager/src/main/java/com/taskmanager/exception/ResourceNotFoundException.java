package com.taskmanager.exception;

/**
 * Custom exception thrown when a requested resource (like a Task or User) is not found.
 * Extends RuntimeException, so it is unchecked.
 */
public class ResourceNotFoundException extends RuntimeException {

    // Constructor to create exception with a specific error message
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
