package com.taskmanager.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.taskmanager.entity.Task;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.stream.Stream;

@Service
public class ReportExportService {

    /**
     * Exports a list of tasks into a PDF document.
     * Generates a table with task details: ID, Title, Description, Status, Due Date.
     * Returns the PDF as a ByteArrayInputStream for easy streaming/downloading.
     */
    public ByteArrayInputStream exportTasksToPdf(List<Task> tasks) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            // Initialize PDF writer with output stream
            PdfWriter.getInstance(document, out);
            document.open();

            // Define header font style
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
            
            // Add centered title
            Paragraph title = new Paragraph("Task Report", headerFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);  // Add space after title

            // Create a table with 5 columns for task attributes
            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100); // full width

            // Add table headers
            Stream.of("ID", "Title", "Description", "Status", "Due Date")
                    .forEach(header -> {
                        PdfPCell headerCell = new PdfPCell(new Phrase(header, headerFont));
                        headerCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                        table.addCell(headerCell);
                    });

            // Add task data rows
            for (Task task : tasks) {
                table.addCell(String.valueOf(task.getId()));
                table.addCell(task.getTitle());
                table.addCell(task.getDescription());
                table.addCell(task.getStatus().name());
                table.addCell(task.getDueDate().toString());
            }

            // Add the table to the document and close
            document.add(table);
            document.close();
        } catch (DocumentException ex) {
            ex.printStackTrace();  // Log exception if occurs
        }

        // Return the generated PDF bytes as input stream
        return new ByteArrayInputStream(out.toByteArray());
    }
}
