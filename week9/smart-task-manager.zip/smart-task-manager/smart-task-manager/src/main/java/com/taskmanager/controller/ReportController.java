package com.taskmanager.controller;

import com.taskmanager.dto.TaskSummaryDto;
import com.taskmanager.service.ReportService;
import lombok.RequiredArgsConstructor;

import java.util.Map;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * ReportController handles endpoints related to analytics and reporting.
 * Access restricted to ADMIN and MANAGER roles.
 */
@RestController
@RequestMapping("/api/reports") // Base URL for report-related APIs
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService; // Service to provide report data and exports

    /**
     * Get a summary of tasks for dashboard analytics.
     * Returns total tasks, completed, pending, and in-progress counts.
     */
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')") // Only ADMIN or MANAGER can access
    @GetMapping("/summary")
    public ResponseEntity<TaskSummaryDto> getTaskSummary() {
        TaskSummaryDto summary = reportService.getTaskSummary();
        return ResponseEntity.ok(summary);
    }

    /**
     * Export task summary as a downloadable PDF file.
     */
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @GetMapping("/export/pdf")
    public ResponseEntity<ByteArrayResource> exportTaskSummaryAsPdf() {
        byte[] pdfData = reportService.generateSummaryPdf();
        ByteArrayResource resource = new ByteArrayResource(pdfData);

        // Set headers to indicate file type and force download with filename
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDisposition(ContentDisposition.attachment().filename("task-summary.pdf").build());

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(pdfData.length)
                .body(resource);
    }
    
    /**
     * Export task summary as a downloadable Excel file.
     */
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @GetMapping("/export/excel")
    public ResponseEntity<ByteArrayResource> exportTaskSummaryAsExcel() {
        byte[] excelData = reportService.generateSummaryExcel();
        ByteArrayResource resource = new ByteArrayResource(excelData);

        // Set headers for Excel file download
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDisposition(ContentDisposition.attachment().filename("task-summary.xlsx").build());

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(excelData.length)
                .body(resource);
    }
    
    /**
     * Get a JSON map representing number of completed tasks per employee.
     * Can be used to render charts on the frontend.
     */
    @PreAuthorize("hasAnyRole('ADMIN', 'MANAGER')")
    @GetMapping("/charts/completed-by-employee")
    public ResponseEntity<Map<String, Long>> getCompletedTasksByEmployeeChart() {
        return ResponseEntity.ok(reportService.getCompletedTasksByEmployee());
    }

}
