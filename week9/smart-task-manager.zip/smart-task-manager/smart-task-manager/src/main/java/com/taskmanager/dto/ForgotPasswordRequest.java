package com.taskmanager.dto;

import lombok.Data;

@Data
public class ForgotPasswordRequest {
    // Email address of the user who requested password reset
    private String email;
}
