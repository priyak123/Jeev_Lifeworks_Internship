package com.taskmanager.service;

import java.util.Map;
import com.taskmanager.dto.TaskSummaryDto;

/**
 * Service interface for generating task reports and exporting summaries.
 */
public interface ReportService {

    /**
     * Retrieves a summary of tasks (total, completed, pending, overdue, etc.).
     * @return TaskSummaryDto containing aggregated task data
     */
    TaskSummaryDto getTaskSummary();

    /**
     * Generates a PDF report of the task summary.
     * @return byte array representing the PDF file content
     */
    byte[] generateSummaryPdf();

    /**
     * Generates an Excel report of the task summary.
     * @return byte array representing the Excel file content
     */
    byte[] generateSummaryExcel();

    /**
     * Gets the count of completed tasks grouped by employee name.
     * @return Map where key = employee full name, value = completed task count
     */
    Map<String, Long> getCompletedTasksByEmployee();
}
