package com.taskmanager.service;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Map;

@Service
public class ChartService {

    /**
     * Generates a bar chart showing the number of tasks assigned to each user.
     *
     * @param taskCountsByUser a map where key = user full name, value = task count
     * @return byte[] PNG chart image as byte array
     */
    public byte[] generateTaskCountBarChart(Map<String, Long> taskCountsByUser) {
        // Create dataset for the bar chart
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Add task count data for each user into the dataset
        taskCountsByUser.forEach((username, count) -> {
            dataset.addValue(count, "Tasks", username);
        });

        // Create a bar chart with title and axis labels
        JFreeChart chart = ChartFactory.createBarChart(
                "Tasks per User",     // chart title
                "User",               // x-axis label
                "Task Count",         // y-axis label
                dataset               // dataset containing the data
        );

        // Write chart as PNG image bytes to a ByteArrayOutputStream
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ChartUtils.writeChartAsPNG(baos, chart, 800, 600);
            return baos.toByteArray();  // Return image as byte array
        } catch (Exception e) {
            throw new RuntimeException("Failed to generate chart", e);
        }
    }
}
