package com.taskmanager.service.impl;

import com.taskmanager.dto.TaskDto;
import com.taskmanager.entity.Task;
import com.taskmanager.entity.TaskPriority;
import com.taskmanager.entity.TaskStatus;
import com.taskmanager.entity.User;
import com.taskmanager.repository.TaskRepository;
import com.taskmanager.repository.UserRepository;
import com.taskmanager.service.EmailService;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceImplTest {

    // Mock dependencies used inside TaskServiceImpl
    @Mock private TaskRepository taskRepository;
    @Mock private UserRepository userRepository;
    @Mock private EmailService emailService;

    // Inject mocks into the service instance
    @InjectMocks private TaskServiceImpl taskService;

    // Test creating a task with valid input
    @Test
    void testCreateTask() {
        // Prepare input DTO for creating a task
        TaskDto dto = new TaskDto("Test", "Test Desc", TaskStatus.TODO, LocalDate.now(), 1L, TaskPriority.MEDIUM);

        // Prepare a mock user who will be assigned the task
        User user = new User();
        user.setId(1L);
        user.setFullName("Test User");
        user.setEmail("test@example.com");

        // Prepare the Task object that the repository will return after saving
        Task savedTask = Task.builder()
                .id(101L)
                .title(dto.getTitle())
                .description(dto.getDescription())
                .status(dto.getStatus())
                .dueDate(dto.getDueDate())
                .assignedTo(user)
                .priority(dto.getPriority())
                .build();

        // Mock repository behavior
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(taskRepository.save(any(Task.class))).thenReturn(savedTask);

        // Call the service method
        Task task = taskService.createTask(dto);

        // Assertions to verify the returned task is correct
        assertNotNull(task);
        assertEquals("Test", task.getTitle());
        assertEquals(TaskStatus.TODO, task.getStatus());
        assertEquals("Test User", task.getAssignedTo().getFullName());

        // Verify that taskRepository.save was called exactly once
        verify(taskRepository, times(1)).save(any(Task.class));

        // Verify that emailService.sendEmail was called once to notify the assigned user
        verify(emailService, times(1)).sendEmail(eq("test@example.com"), anyString(), anyString());
    }

    // Test updating an existing task
    @Test
    void testUpdateTask() {
        Long taskId = 101L;
        TaskDto dto = new TaskDto("Updated Title", "Updated Desc", TaskStatus.IN_PROGRESS, LocalDate.now(), 1L, TaskPriority.MEDIUM);

        // Existing user and task setup
        User user = new User(); user.setId(1L);

        Task existingTask = Task.builder()
                .id(taskId)
                .title("Old Title")
                .description("Old Desc")
                .status(TaskStatus.TODO)
                .dueDate(LocalDate.now().plusDays(5))
                .assignedTo(user)
                .build();

        // Mock repository behavior
        when(taskRepository.findById(taskId)).thenReturn(Optional.of(existingTask));
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Call the service update method
        Task updated = taskService.updateTask(taskId, dto);

        // Assertions to verify that the task was updated correctly
        assertNotNull(updated);
        assertEquals("Updated Title", updated.getTitle());
        assertEquals(TaskStatus.IN_PROGRESS, updated.getStatus());
    }

    // Test deleting a task by id
    @Test
    void testDeleteTask() {
        Long taskId = 101L;

        // Mock the delete method to do nothing
        doNothing().when(taskRepository).deleteById(taskId);

        // Call the delete method
        taskService.deleteTask(taskId);

        // Verify that deleteById was called once
        verify(taskRepository, times(1)).deleteById(taskId);
    }

    // Test retrieving all tasks
    @Test
    void testGetAllTasks() {
        // Prepare a list of mock tasks
        List<Task> tasks = Arrays.asList(new Task(), new Task());

        // Mock repository to return the list
        when(taskRepository.findAll()).thenReturn(tasks);

        // Call service method to get all tasks
        List<Task> result = taskService.getAllTasks();

        // Assert that returned list size matches
        assertEquals(2, result.size());
    }

    // Test retrieving tasks assigned to a specific user
    @Test
    void testGetTasksForUser() {
        Long userId = 1L;
        User user = new User(); user.setId(userId);

        // Prepare mock list of tasks assigned to user
        List<Task> taskList = Arrays.asList(new Task(), new Task());

        // Mock user and task repository calls
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(taskRepository.findByAssignedTo(user)).thenReturn(taskList);

        // Call service method to get tasks for user
        List<Task> result = taskService.getTasksForUser(userId);

        // Assert the returned task count matches
        assertEquals(2, result.size());

        // Verify that findByAssignedTo was called with correct user
        verify(taskRepository).findByAssignedTo(user);
    }
}
