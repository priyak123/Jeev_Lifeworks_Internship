import java.util.Scanner;

public class Task {

	public static void main(String[] args) {
		
	int a,b;
	float c;
	char d;
	boolean f;
	String name;
	
	System.out.print("Enter the first Integer: ");	
	Scanner scan= new Scanner(System.in) ;
	a= scan.nextInt();
	System.out.print("Enter the second Integer:");
	b=scan.nextInt();
	System.out.print("Enter a floating - point number:");
	c=scan.nextFloat();
	System.out.print("Enter a single Character:");
	d=scan.next().charAt(0);
	System.out.print("Enter a boolean value (True/False):");
	f=scan.nextBoolean();
	System.out.print("Enter your name:");
	name=scan.next();
	
	System.out.println("sum of "+a+" and "+b+" is : "+(a+b));
	System.out.println("difference between "+a+" and "+b+" is : "+(a-b));
	System.out.println("product of "+a+" and "+b+" is : "+(a*b));
	System.out.println(c +" Multiplied "+" by " + " 2 "+" is : " +(c*2));
	System.out.println("The next character after " + d + " is :"+(char)(d+1));
	System.out.println("The oposite of " + f+" is :" +!f);
	System.out.println("Enter your name : "+name);       
	}

}
