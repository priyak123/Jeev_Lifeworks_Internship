package com.example.document_metadata_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentMetadataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
