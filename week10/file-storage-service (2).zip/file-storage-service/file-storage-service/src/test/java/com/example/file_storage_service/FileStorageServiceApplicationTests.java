package com.example.file_storage_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileStorageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
